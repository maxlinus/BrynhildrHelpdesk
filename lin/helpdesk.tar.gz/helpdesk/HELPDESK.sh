#!/bin/sh
killall x11vnc
ID=`shuf -i 100000-999999 -n 1`
./x11vnc -connect repeater=ID:$ID+90.188.238.128:5509 -solid -ultrafilexfer -speeds dsl -bg
zenity --info --text '<i>Lait-Soft HELPDESK</i>\n\n<span foreground="red" font="16">\НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО</span>\n\n<span foreground="black" font="24">\Ваш ID</span>\n\n<span foreground="blue" font="32">'$ID' </span>\n\n<i>www.lait-soft.ru</i>'
killall x11vnc