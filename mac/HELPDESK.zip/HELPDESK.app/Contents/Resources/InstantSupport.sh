#!/bin/sh

# Generate number between 100000 and 200000
idnumber=0
while [ "$idnumber" -le 100000 ]
do
  idnumber=$RANDOM+100000
  let "idnumber %= 200000"
done
echo $idnumber


# Create our connection string
connect_str="-connect repeater://helpdesk38.ru:5509+ID:$idnumber"
echo $connect_str

./CocoaDialog msgbox --text "$idnumber" --informative-text "Please provide this number to the support agent before clicking connect." --button1 "Connect"

# Establish our reverse connection
./x11vnc $connect_str